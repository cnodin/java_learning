package org.pollux.feigndemo.service;

import org.pollux.feigndemo.api.HelloFeignService;
import org.springframework.stereotype.Service;

/**
 * Created with IntelliJ IDEA.
 * User: spock.wang
 * Date: 2019-05-02
 * Time: 17:20
 * To change this template use File | Settings | File Templates.
 * Description:
 */
@Service
public class HelloFeignServiceImpl implements HelloFeignService {
    @Override
    public String searchRepo(String queryStr) {
        return "this is local method";
    }
}
