package org.pollux.sofademo.sofademo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SofaDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SofaDemoApplication.class, args);
	}

}
